#!/bin/sh
# Add PATH and MANPATH for teTeX:
PATH="$PATH:/usr/share/texmf/bin"
MANPATH="$MANPATH:/usr/share/texmf/man"
