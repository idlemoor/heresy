T1LIB_CONFIG=/usr/share/t1lib/t1lib.config
export T1LIB_CONFIG
