#!/bin/sh

# SCIM (Smart Common Input Method platform).  This is used to support the
# entering of text in non-US-English languages.

# For SCIM to work, you need to use a UTF-8 locale.  Make sure it ends on
# ".UTF-8", not "utf-8"!  As an example, you would need to use en_US.UTF-8
# for a US locale (export LANG=en_US.UTF-8), not en_US.
#
# The locale (LANG variable) is set in /etc/profile.d/lang.sh.

if [ -x /usr/bin/scim ]; then
  # Enable legacy X applications to use scim:
  export XMODIFIERS="@im=SCIM"
  # Let GTK applications like Firefox/Thunderbird use scim as
  # default immodule:
  export GTK_IM_MODULE="scim"
  # Enable Qt/KDE applications to use scim:
  export QT_IM_MODULE="scim"
  # Make scim start automatically if the "magic key" Ctrl-Space is pressed:
  export XIM_PROGRAM="/usr/bin/scim -d"
fi

# This ensures scim starts when you logon.
# This will only work if you login through runlevel 4 (graphical login)!!!
# Better is to have it start through Ctrl-Space like configured higher up ^^.
#if [ ! `ls /tmp/scim-socket*` ]; then
#  /usr/bin/scim -d
#fi

